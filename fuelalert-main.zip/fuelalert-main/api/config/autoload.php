<?php
include('dotenv.php');
include('functions.php');
include('../models/User.php');
include('sqlitecon.php');
include('../models/Mail.php');
